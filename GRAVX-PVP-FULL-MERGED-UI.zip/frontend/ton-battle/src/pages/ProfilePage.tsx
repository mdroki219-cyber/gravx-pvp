import { useNavigate } from 'react-router-dom'
import { Wallet, ArrowUpRight, Users, CheckSquare, History, ChevronRight } from 'lucide-react'
import type { User } from '../types'

interface Props {
  user: User
}

const menuItems = [
  { icon: Wallet, label: 'Deposit', path: '/deposit', color: 'text-emerald-400' },
  { icon: ArrowUpRight, label: 'Withdraw', path: '/withdraw', color: 'text-orange-400' },
  { icon: Users, label: 'Referrals', path: '/referrals', color: 'text-purple-400' },
  { icon: CheckSquare, label: 'Tasks', path: '/tasks', color: 'text-cyan-400' },
  { icon: History, label: 'History', path: '/history', color: 'text-blue-400' },
]

export default function ProfilePage({ user }: Props) {
  const navigate = useNavigate()

  return (
    <div className="safe-top safe-bottom min-h-screen pb-20 px-4 pt-4">
      {/* Profile header */}
      <div className="flex flex-col items-center mb-6">
        <img
          src={user.avatar}
          alt=""
          className="w-20 h-20 rounded-full border-4 border-cyan-400/40 mb-3"
        />
        <h2 className="text-xl font-bold">@{user.username}</h2>
        <p className="text-xs text-gray-400 mt-1">ID: {user.telegram_id}</p>
      </div>

      {/* Balance card */}
      <div className="bg-gradient-to-br from-ton-card to-[#0F1A2A] border border-ton-border rounded-2xl p-5 mb-5 text-center">
        <p className="text-xs text-gray-400 uppercase tracking-wider">TON Balance</p>
        <p className="text-3xl font-extrabold text-cyan-300 mt-1">{user.ton_balance.toFixed(2)}</p>
        <p className="text-xs text-gray-500 mt-1">Total Wins: {user.total_wins.toFixed(2)} TON</p>
      </div>

      {/* Menu */}
      <div className="space-y-2">
        {menuItems.map(item => {
          const Icon = item.icon
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="w-full flex items-center gap-4 bg-ton-card border border-ton-border rounded-2xl px-4 py-4 btn-press active:scale-[0.98] transition-transform"
            >
              <div className={`w-10 h-10 rounded-xl bg-ton-dark flex items-center justify-center ${item.color}`}>
                <Icon size={20} />
              </div>
              <span className="flex-1 text-left font-medium">{item.label}</span>
              <ChevronRight size={18} className="text-gray-500" />
            </button>
          )
        })}
      </div>
    </div>
  )
}
