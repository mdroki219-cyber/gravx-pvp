import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { mockHistory } from '../store/mockData'
import clsx from 'clsx'

export default function HistoryPage() {
  const navigate = useNavigate()

  const typeLabel = (t: string) => {
    const map: Record<string, string> = {
      pvp_win: 'PVP WIN',
      pvp_bet: 'PVP BET',
      roulette: 'ROULETTE',
      deposit: 'DEPOSIT',
      withdraw: 'WITHDRAW',
      referral: 'REFERRAL',
    }
    return map[t] || t.toUpperCase()
  }

  return (
    <div className="safe-top min-h-screen px-4 pt-4 pb-8">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-400 mb-5">
        <ArrowLeft size={20} /> Back
      </button>

      <h1 className="text-2xl font-bold mb-5">History</h1>

      <div className="space-y-2">
        {mockHistory.map(tx => (
          <div
            key={tx.id}
            className="bg-ton-card border border-ton-border rounded-2xl px-4 py-3 flex items-center justify-between"
          >
            <div>
              <p className="font-medium text-sm">{typeLabel(tx.type)}</p>
              <p className="text-xs text-gray-400 mt-0.5">
                {tx.game_id ? `Game #${tx.game_id}` : tx.wallet_address || ''}
                {' • '}
                {new Date(tx.created_at).toLocaleDateString()}
              </p>
            </div>
            <div className="text-right">
              <p className={clsx(
                'font-bold text-sm',
                tx.amount > 0 ? 'text-emerald-400' : 'text-red-400'
              )}>
                {tx.amount > 0 ? '+' : ''}{tx.amount.toFixed(2)} TON
              </p>
              <p className={clsx(
                'text-xs mt-0.5 capitalize',
                tx.status === 'completed' && 'text-gray-400',
                tx.status === 'processing' && 'text-yellow-400',
                tx.status === 'pending' && 'text-blue-400',
                tx.status === 'failed' && 'text-red-400'
              )}>
                {tx.status}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
