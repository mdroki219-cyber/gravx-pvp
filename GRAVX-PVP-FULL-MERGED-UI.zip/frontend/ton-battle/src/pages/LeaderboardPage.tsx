import { mockLeaderboard } from '../store/mockData'
import clsx from 'clsx'

export default function LeaderboardPage() {
  return (
    <div className="safe-top safe-bottom min-h-screen pb-20 px-4 pt-4">
      <h1 className="text-xl font-bold mb-1 flex items-center gap-2">
        🏆 TOP WINNERS
      </h1>
      <p className="text-xs text-gray-400 mb-5">Based on total TON won</p>

      <div className="space-y-2">
        {mockLeaderboard.map((entry) => (
          <div
            key={entry.rank}
            className={clsx(
              'flex items-center gap-3 rounded-2xl px-4 py-3 border',
              entry.rank === 1 && 'bg-gradient-to-r from-yellow-500/10 to-transparent border-yellow-500/30',
              entry.rank === 2 && 'bg-gradient-to-r from-gray-400/10 to-transparent border-gray-400/30',
              entry.rank === 3 && 'bg-gradient-to-r from-amber-700/10 to-transparent border-amber-700/30',
              entry.rank > 3 && 'bg-ton-card border-ton-border'
            )}
          >
            <div className={clsx(
              'w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0',
              entry.rank === 1 && 'bg-yellow-500 text-black',
              entry.rank === 2 && 'bg-gray-300 text-black',
              entry.rank === 3 && 'bg-amber-700 text-white',
              entry.rank > 3 && 'bg-ton-dark text-gray-400'
            )}>
              {entry.rank <= 3 ? ['🥇', '🥈', '🥉'][entry.rank - 1] : `#${entry.rank}`}
            </div>

            <img src={entry.avatar} alt="" className="w-10 h-10 rounded-full border border-ton-border" />

            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">@{entry.username}</p>
            </div>

            <p className="font-bold text-cyan-300 text-sm">{entry.total_win.toFixed(2)} TON</p>
          </div>
        ))}
      </div>
    </div>
  )
}
