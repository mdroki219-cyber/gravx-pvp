import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import type { User } from '../types'
import clsx from 'clsx'

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001'

interface Props { user: User; updateBalance: (delta: number) => void; showToast: (msg: string, type?: 'success' | 'error' | 'info') => void }

export default function DepositPage({ user, showToast }: Props) {
  const navigate = useNavigate()
  const [amount, setAmount] = useState('1')
  const [status, setStatus] = useState<'idle'|'pending'>('idle')
  const quick = [0.5, 1, 2, 5, 10, 20]

  const handleDeposit = async () => {
    const val = Number(amount)
    if (!Number.isFinite(val) || val < 0.5) return showToast('Minimum deposit is 0.50 TON', 'error')
    try {
      setStatus('pending')
      const r = await fetch(`${API}/api/wallet/deposit/request`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ telegram_id:user.telegram_id, amount:val }) })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || 'Could not create deposit')
      showToast('Tonkeeper খুলছে — payment confirm করো', 'info')
      window.location.href = d.tonkeeper_url
    } catch (e:any) {
      setStatus('idle'); showToast(e.message || 'Deposit failed', 'error')
    }
  }

  return <div className="safe-top min-h-screen px-4 pt-4 pb-8">
    <button onClick={()=>navigate(-1)} className="flex items-center gap-2 text-gray-400 mb-5"><ArrowLeft size={20}/> Back</button>
    <h1 className="text-2xl font-bold mb-1">Deposit TON</h1>
    <p className="text-sm text-gray-400 mb-6">Current balance: {user.ton_balance.toFixed(2)} TON</p>
    <div className="bg-ton-card border border-ton-border rounded-2xl p-5">
      <label className="text-xs text-gray-400 uppercase tracking-wider">Amount</label>
      <div className="flex items-center gap-2 mt-2"><input type="number" value={amount} onChange={e=>setAmount(e.target.value)} className="flex-1 bg-ton-dark border border-ton-border rounded-xl px-4 py-3 text-xl font-bold text-cyan-300 outline-none" min="0.5" step="0.1"/><span className="text-gray-400 font-medium">TON</span></div>
      <div className="flex flex-wrap gap-2 mt-4">{quick.map(q=><button key={q} onClick={()=>setAmount(String(q))} className={clsx('px-4 py-2 rounded-xl text-sm font-medium border btn-press', amount===String(q)?'bg-cyan-500/20 border-cyan-500 text-cyan-300':'bg-ton-dark border-ton-border text-gray-300')}>{q} TON</button>)}</div>
      <button onClick={handleDeposit} disabled={status!=='idle'} className={clsx('mt-6 w-full py-3.5 rounded-xl font-bold btn-press',status==='idle'?'bg-gradient-to-r from-cyan-500 to-blue-600 text-white glow-cyan':'bg-gray-700 text-gray-400')}>{status==='idle'?'OPEN TONKEEPER':'Waiting for payment...'}</button>
      <p className="text-xs text-gray-500 text-center mt-3">Selected amount is sent exactly. Balance is credited automatically after the TON transaction is detected.</p>
    </div>
  </div>
}
