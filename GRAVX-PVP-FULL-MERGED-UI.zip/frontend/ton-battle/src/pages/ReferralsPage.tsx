import { useNavigate } from 'react-router-dom'
import { ArrowLeft, Copy, Share2 } from 'lucide-react'
import { mockReferrals } from '../store/mockData'
import type { User } from '../types'

interface Props {
  user: User
}

export default function ReferralsPage({ user }: Props) {
  const navigate = useNavigate()
  const link = `https://t.me/YourBot?start=${user.referral_code}`
  const earnings = mockReferrals.reduce((s, r) => s + r.reward, 0)

  const copy = () => {
    navigator.clipboard?.writeText(link)
    alert('Link copied!')
  }

  return (
    <div className="safe-top min-h-screen px-4 pt-4 pb-8">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-400 mb-5">
        <ArrowLeft size={20} /> Back
      </button>

      <h1 className="text-2xl font-bold mb-1">REFER & EARN</h1>
      <p className="text-sm text-gray-400 mb-6">
        Invite friends and earn <span className="text-cyan-300 font-semibold">0.03 TON</span> per successful invite.
      </p>

      <div className="bg-ton-card border border-ton-border rounded-2xl p-5 mb-5">
        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Your Referral Code</p>
        <p className="text-2xl font-extrabold text-cyan-300 tracking-widest">{user.referral_code}</p>

        <p className="text-xs text-gray-400 mt-4 mb-1">Referral Link</p>
        <p className="text-sm text-gray-300 break-all bg-ton-dark rounded-xl px-3 py-2 border border-ton-border">
          {link}
        </p>

        <div className="flex gap-3 mt-4">
          <button
            onClick={copy}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-ton-dark border border-ton-border font-medium btn-press"
          >
            <Copy size={16} /> COPY LINK
          </button>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: 'GRAVX PVP', url: link })
              } else {
                copy()
              }
            }}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-medium btn-press"
          >
            <Share2 size={16} /> SHARE
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-5">
        <div className="bg-ton-card border border-ton-border rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-white">{mockReferrals.length}</p>
          <p className="text-xs text-gray-400">Invited Users</p>
        </div>
        <div className="bg-ton-card border border-ton-border rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-cyan-300">{earnings.toFixed(2)}</p>
          <p className="text-xs text-gray-400">Earnings (TON)</p>
        </div>
      </div>

      <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">Referral History</p>
      <div className="space-y-2">
        {mockReferrals.map((r, i) => (
          <div key={i} className="flex items-center justify-between bg-ton-card border border-ton-border rounded-xl px-4 py-3">
            <span className="text-sm">@{r.username}</span>
            <span className="text-sm font-semibold text-emerald-400">+{r.reward} TON</span>
          </div>
        ))}
      </div>
    </div>
  )
}
