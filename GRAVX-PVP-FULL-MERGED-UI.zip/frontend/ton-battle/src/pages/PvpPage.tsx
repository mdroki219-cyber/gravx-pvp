import { useState, useEffect, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Minus, Plus, Trophy } from 'lucide-react'
import { BET_AMOUNTS, COLORS, calcChances, initialPvpGame } from '../store/mockData'
import type { User, PvpGame, PvpPlayer } from '../types'
import clsx from 'clsx'

interface Props {
  user: User
  updateBalance: (delta: number) => void
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void
}

export default function PvpPage({ user, updateBalance, showToast }: Props) {
  const [game, setGame] = useState<PvpGame>(initialPvpGame)
  const [betIndex, setBetIndex] = useState(0) // 0.20 default
  const [hasBet, setHasBet] = useState(false)
  const [spinning, setSpinning] = useState(false)
  const [rotation, setRotation] = useState(0)

  const betAmount = BET_AMOUNTS[betIndex]

  // Countdown
  useEffect(() => {
    if (game.status !== 'betting' || game.countdown <= 0) return
    const t = setInterval(() => {
      setGame(g => {
        if (g.countdown <= 1) {
          // Start spin
          setTimeout(() => startSpin(), 400)
          return { ...g, countdown: 0, status: 'spinning' }
        }
        return { ...g, countdown: g.countdown - 1 }
      })
    }, 1000)
    return () => clearInterval(t)
  }, [game.status, game.countdown])

  const startSpin = () => {
    setSpinning(true)
    // Random winner based on weight
    const players = game.players
    const total = players.reduce((s, p) => s + p.bet, 0)
    let r = Math.random() * total
    let winner = players[0]
    for (const p of players) {
      r -= p.bet
      if (r <= 0) {
        winner = p
        break
      }
    }

    // Calculate rotation so it lands on winner segment
    let cumulative = 0
    const segments = players.map(p => {
      const size = (p.bet / total) * 360
      const start = cumulative
      cumulative += size
      return { player: p, start, size }
    })
    const winSeg = segments.find(s => s.player.id === winner.id)!
    const landAt = winSeg.start + winSeg.size / 2
    const extraSpins = 4 + Math.random() * 2
    const finalRotation = extraSpins * 360 + (360 - landAt)

    setRotation(finalRotation)

    setTimeout(() => {
      setSpinning(false)
      setGame(g => ({
        ...g,
        status: 'result',
        winner,
        ended_at: new Date().toISOString(),
      }))

      if (winner.username === user.username || winner.id === 'me') {
        const payout = +(game.total_pot * 0.90).toFixed(2) // 10% platform fee
        updateBalance(payout)
        showToast(`You won ${payout} TON! 🏆`, 'success')
      } else {
        showToast(`${winner.username} won the pot!`, 'info')
      }

      // New round after 5s
      setTimeout(() => {
        setHasBet(false)
        setRotation(0)
        setGame({
          ...initialPvpGame,
          game_id: `TB-${Math.floor(90000 + Math.random() * 9999)}`,
          countdown: 30,
          players: calcChances([
            { id: '1', username: 'CryptoKing', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CryptoKing', bet: 3.2, color: COLORS[0], chance: 0 },
            { id: '2', username: 'NovaStrike', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=NovaStrike', bet: 1.6, color: COLORS[1], chance: 0 },
          ]),
          total_pot: 4.8,
          status: 'betting',
          winner: null,
        })
      }, 5500)
    }, 4200)
  }

  const placeBet = () => {
    if (hasBet) {
      showToast('You already placed a bet this round', 'error')
      return
    }
    if (user.ton_balance < betAmount) {
      showToast('Insufficient TON balance. Please deposit first.', 'error')
      return
    }

    updateBalance(-betAmount)
    const me: PvpPlayer = {
      id: 'me',
      username: user.username,
      avatar: user.avatar,
      bet: betAmount,
      color: COLORS[3],
      chance: 0,
    }
    const newPlayers = calcChances([...game.players, me])
    const newPot = newPlayers.reduce((s, p) => s + p.bet, 0)

    setGame(g => ({
      ...g,
      players: newPlayers,
      total_pot: +newPot.toFixed(2),
    }))
    setHasBet(true)
    showToast(`Bet placed: ${betAmount} TON`, 'success')
  }

  const incBet = () => setBetIndex(i => Math.min(i + 1, BET_AMOUNTS.length - 1))
  const decBet = () => setBetIndex(i => Math.max(i - 1, 0))

  // Wheel segments
  const segments = useMemo(() => {
    const total = game.total_pot || 1
    let cumulative = 0
    return game.players.map(p => {
      const pct = (p.bet / total) * 100
      const start = cumulative
      cumulative += pct
      return { ...p, startPct: start, pct }
    })
  }, [game.players, game.total_pot])

  return (
    <div className="safe-top safe-bottom min-h-screen pb-20">
      {/* Header */}
      <div className="px-4 pt-4 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={user.avatar} alt="" className="w-10 h-10 rounded-full border-2 border-cyan-400/50" />
          <div>
            <p className="text-sm font-semibold">@{user.username}</p>
            <p className="text-xs text-gray-400">Game #{game.game_id}</p>
          </div>
        </div>
        <div className="bg-ton-card border border-ton-border rounded-full px-4 py-1.5 flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500" />
          <span className="font-bold text-cyan-300">{user.ton_balance.toFixed(2)} TON</span>
        </div>
      </div>

      {/* Pot + Timer */}
      <div className="mx-4 mt-3 gravx-glass bg-ton-card border border-ton-border rounded-2xl p-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-wider">Total Pot</p>
          <p className="text-2xl font-extrabold text-cyan-300">{game.total_pot.toFixed(2)} TON</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-400 uppercase tracking-wider">
            {game.status === 'betting' ? 'Betting ends in' : game.status === 'spinning' ? 'Spinning...' : 'Result'}
          </p>
          <p className={clsx(
            'text-2xl font-extrabold',
            game.countdown <= 5 && game.status === 'betting' ? 'text-red-400' : 'text-white'
          )}>
            {game.status === 'betting' ? `${game.countdown}s` : game.status === 'spinning' ? '🎯' : '🏆'}
          </p>
        </div>
      </div>

      {/* Wheel */}
      <div className="relative mx-auto mt-6 w-64 h-64 sm:w-72 sm:h-72">
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-20">
          <div className="w-0 h-0 border-l-[10px] border-r-[10px] border-t-[18px] border-l-transparent border-r-transparent border-t-cyan-400 drop-shadow-lg" />
        </div>

        <div
          className="w-full h-full rounded-full overflow-hidden border-4 border-ton-border relative"
          style={{
            transform: `rotate(${rotation}deg)`,
            transition: spinning ? 'transform 4s cubic-bezier(0.15, 0.85, 0.25, 1)' : 'none',
            background: segments.length
              ? `conic-gradient(${segments.map(s => `${s.color} ${s.startPct}% ${s.startPct + s.pct}%`).join(', ')})`
              : '#1a2332',
          }}
        >
          {/* Center circle */}
          <div className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-ton-dark border-4 border-ton-border flex items-center justify-center z-10">
            <span className="text-xs font-bold text-cyan-400">SPIN</span>
          </div>
        </div>
      </div>

      {/* Player list */}
      <div className="mx-4 mt-5 space-y-2 max-h-40 overflow-y-auto">
        {game.players.map(p => (
          <div
            key={p.id}
            className="flex items-center gap-3 bg-ton-card/80 border border-ton-border rounded-xl px-3 py-2"
          >
            <div className="w-3 h-3 rounded-full shrink-0" style={{ background: p.color }} />
            <img src={p.avatar} alt="" className="w-8 h-8 rounded-full" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">@{p.username}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-cyan-300">{p.bet.toFixed(2)} TON</p>
              <p className="text-xs text-gray-400">{p.chance.toFixed(1)}%</p>
            </div>
          </div>
        ))}
      </div>

      {/* Bet controls */}
      {game.status === 'betting' && (
        <div className="mx-4 mt-5 gravx-glass bg-ton-card border border-ton-border rounded-2xl p-4">
          <p className="text-xs text-gray-400 text-center mb-3">Select Bet Amount</p>
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={decBet}
              disabled={betIndex === 0}
              className="w-12 h-12 rounded-full bg-ton-dark border border-ton-border flex items-center justify-center disabled:opacity-40 btn-press"
            >
              <Minus size={20} />
            </button>
            <div className="min-w-[100px] text-center">
              <p className="text-2xl font-extrabold text-cyan-300">{betAmount.toFixed(2)}</p>
              <p className="text-xs text-gray-400">TON</p>
            </div>
            <button
              onClick={incBet}
              disabled={betIndex === BET_AMOUNTS.length - 1}
              className="w-12 h-12 rounded-full bg-ton-dark border border-ton-border flex items-center justify-center disabled:opacity-40 btn-press"
            >
              <Plus size={20} />
            </button>
          </div>

          <button
            onClick={placeBet}
            disabled={hasBet}
            className={clsx(
              'mt-4 w-full py-3.5 rounded-xl font-bold text-base btn-press transition-all',
              hasBet
                ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white glow-cyan'
            )}
          >
            {hasBet ? 'BET PLACED' : 'PLACE BET'}
          </button>
        </div>
      )}

      {/* Result overlay */}
      <AnimatePresence>
        {game.status === 'result' && game.winner && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-30 bg-black/70 flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.8, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-ton-card border border-cyan-500/40 rounded-3xl p-6 w-full max-w-sm text-center glow-cyan"
            >
              <Trophy className="mx-auto text-yellow-400 mb-3" size={48} />
              <p className="text-sm text-gray-400 uppercase tracking-wider">Winner</p>
              <p className="text-2xl font-extrabold text-white mt-1">@{game.winner.username}</p>
              <p className="text-3xl font-black text-cyan-300 mt-3">
                +{(game.total_pot * 0.97).toFixed(2)} TON
              </p>
              <p className="text-xs text-gray-500 mt-2">Game #{game.game_id}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
