import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { mockTasks } from '../store/mockData'
import type { Task } from '../types'
import clsx from 'clsx'

interface Props {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void
}

export default function TasksPage({ showToast }: Props) {
  const navigate = useNavigate()
  const [tasks, setTasks] = useState<Task[]>(mockTasks)

  const handleAction = (task: Task) => {
    if (task.status === 'available') {
      setTasks(ts => ts.map(t => t.id === task.id ? { ...t, status: 'in_progress' } : t))
      showToast(`Started: ${task.name}`, 'info')
      // Simulate completion
      setTimeout(() => {
        setTasks(ts => ts.map(t => t.id === task.id ? { ...t, status: 'completed' } : t))
        showToast(`Task completed! Claim your reward.`, 'success')
      }, 2000)
    } else if (task.status === 'completed') {
      setTasks(ts => ts.map(t => t.id === task.id ? { ...t, status: 'claimed' } : t))
      showToast(`+${task.reward} TON claimed!`, 'success')
    }
  }

  const statusLabel = (s: Task['status']) => {
    if (s === 'available') return 'START'
    if (s === 'in_progress') return 'IN PROGRESS'
    if (s === 'completed') return 'CLAIM'
    return 'CLAIMED'
  }

  return (
    <div className="safe-top min-h-screen px-4 pt-4 pb-8">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-400 mb-5">
        <ArrowLeft size={20} /> Back
      </button>

      <h1 className="text-2xl font-bold mb-5">TASKS</h1>

      <div className="space-y-3">
        {tasks.map(task => (
          <div
            key={task.id}
            className="bg-ton-card border border-ton-border rounded-2xl px-4 py-4 flex items-center gap-4"
          >
            <div className="flex-1">
              <p className="font-medium">{task.name}</p>
              <p className="text-sm text-cyan-300 mt-0.5">+{task.reward} TON</p>
            </div>
            <button
              onClick={() => handleAction(task)}
              disabled={task.status === 'in_progress' || task.status === 'claimed'}
              className={clsx(
                'px-4 py-2 rounded-xl text-sm font-bold btn-press min-w-[100px]',
                task.status === 'available' && 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40',
                task.status === 'in_progress' && 'bg-gray-700 text-gray-400',
                task.status === 'completed' && 'bg-emerald-500 text-white',
                task.status === 'claimed' && 'bg-gray-800 text-gray-500'
              )}
            >
              {statusLabel(task.status)}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
