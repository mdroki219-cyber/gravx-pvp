import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import type { User } from '../types'
import clsx from 'clsx'
const API = import.meta.env.VITE_API_URL || 'http://localhost:3001'
interface Props { user: User; updateBalance: (delta: number) => void; showToast: (msg: string, type?: 'success'|'error'|'info') => void }
export default function WithdrawPage({ user, showToast }: Props) {
  const navigate=useNavigate(); const [amount,setAmount]=useState(''); const [address,setAddress]=useState(''); const [status,setStatus]=useState<'idle'|'processing'|'done'>('idle')
  const fee=0.10
  const handleWithdraw=async()=>{
    const val=Number(amount)
    if(!Number.isFinite(val)||val<1)return showToast('Minimum withdrawal is 1 TON','error')
    if(!address||address.length<10)return showToast('Enter a valid TON wallet address','error')
    if(user.ton_balance < val+fee)return showToast(`Need ${fee.toFixed(2)} TON fee also`,'error')
    try{setStatus('processing');const r=await fetch(`${API}/api/wallet/withdraw/request`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({telegram_id:user.telegram_id,amount:val,wallet_address:address})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Withdrawal failed');setStatus('done');showToast(`Withdrawal request created. Admin will send ${val} TON manually.`,'success');setTimeout(()=>navigate('/profile'),1800)}catch(e:any){setStatus('idle');showToast(e.message||'Withdrawal failed','error')}
  }
  return <div className="safe-top min-h-screen px-4 pt-4 pb-8"><button onClick={()=>navigate(-1)} className="flex items-center gap-2 text-gray-400 mb-5"><ArrowLeft size={20}/> Back</button><h1 className="text-2xl font-bold mb-1">Withdraw TON</h1><p className="text-sm text-gray-400 mb-6">Available: {user.ton_balance.toFixed(2)} TON · Fee: {fee.toFixed(2)} TON</p><div className="bg-ton-card border border-ton-border rounded-2xl p-5 space-y-4"><div><label className="text-xs text-gray-400 uppercase">Amount</label><div className="flex items-center gap-2 mt-2"><input type="number" value={amount} onChange={e=>setAmount(e.target.value)} className="flex-1 bg-ton-dark border border-ton-border rounded-xl px-4 py-3 text-xl font-bold text-cyan-300 outline-none" placeholder="0.00" min="1"/><button onClick={()=>setAmount(String(Math.max(0,user.ton_balance-fee).toFixed(2)))} className="text-xs text-cyan-400 font-medium px-2">MAX</button></div></div><div><label className="text-xs text-gray-400 uppercase">TON Wallet Address</label><input value={address} onChange={e=>setAddress(e.target.value)} className="w-full mt-2 bg-ton-dark border border-ton-border rounded-xl px-4 py-3 text-sm outline-none" placeholder="EQ... / UQ..."/></div><button onClick={handleWithdraw} disabled={status!=='idle'} className={clsx('w-full py-3.5 rounded-xl font-bold btn-press mt-2',status==='idle'?'bg-gradient-to-r from-orange-500 to-red-500 text-white':'bg-gray-700 text-gray-400')}>{status==='idle'?'REQUEST WITHDRAWAL':status==='processing'?'Submitting...':'REQUESTED ✓'}</button><p className="text-xs text-gray-500 text-center">Withdrawals are manual: you request, then Admin sends TON from the platform wallet.</p></div></div>
}
