import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import SplashScreen from './components/SplashScreen'
import BottomNav from './components/BottomNav'
import PvpPage from './pages/PvpPage'
import RoulettePage from './pages/RoulettePage'
import LeaderboardPage from './pages/LeaderboardPage'
import ProfilePage from './pages/ProfilePage'
import DepositPage from './pages/DepositPage'
import WithdrawPage from './pages/WithdrawPage'
import ReferralsPage from './pages/ReferralsPage'
import TasksPage from './pages/TasksPage'
import HistoryPage from './pages/HistoryPage'
import Toast from './components/Toast'
import { mockUser } from './store/mockData'
import type { User, TabId } from './types'

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001'

export default function App() {
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<User>(mockUser)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)
  const [activeTab, setActiveTab] = useState<TabId>('pvp')

  useEffect(() => {
    let alive = true
    const boot = async () => {
      if (window.Telegram?.WebApp) {
        window.Telegram.WebApp.ready()
        window.Telegram.WebApp.expand()
      }
      const tgUser = window.Telegram?.WebApp?.initDataUnsafe?.user
      const telegram_id = tgUser?.id ?? mockUser.telegram_id
      try {
        const r = await fetch(`${API}/api/auth/login`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({
          telegram_id, username:tgUser?.username || tgUser?.first_name || mockUser.username, avatar:tgUser?.photo_url || mockUser.avatar
        }) })
        const d = await r.json()
        if (alive && r.ok && d.user) setUser(d.user)
      } catch {}
      setTimeout(() => alive && setLoading(false), 1200)
    }
    boot()
    return () => { alive = false }
  }, [])

  useEffect(() => {
    if (loading) return
    const refresh = async () => {
      try {
        const r = await fetch(`${API}/api/auth/me/${user.telegram_id}`)
        const d = await r.json()
        if (r.ok && d.user) setUser(d.user)
      } catch {}
    }
    refresh()
    const id = setInterval(refresh, 8000)
    return () => clearInterval(id)
  }, [loading, user.telegram_id])

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 2800)
  }

  const updateBalance = (delta: number) => {
    setUser(prev => ({ ...prev, ton_balance: Math.max(0, +(prev.ton_balance + delta).toFixed(2)) }))
  }

  if (loading) {
    return <SplashScreen />
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-ton-dark text-white relative">
        <Routes>
          <Route path="/" element={<Navigate to="/pvp" replace />} />
          <Route path="/pvp" element={
            <PvpPage user={user} updateBalance={updateBalance} showToast={showToast} />
          } />
          <Route path="/roulette" element={
            <RoulettePage user={user} updateBalance={updateBalance} showToast={showToast} />
          } />
          <Route path="/leaderboard" element={<LeaderboardPage />} />
          <Route path="/profile" element={<ProfilePage user={user} />} />
          <Route path="/deposit" element={
            <DepositPage user={user} updateBalance={updateBalance} showToast={showToast} />
          } />
          <Route path="/withdraw" element={
            <WithdrawPage user={user} updateBalance={updateBalance} showToast={showToast} />
          } />
          <Route path="/referrals" element={<ReferralsPage user={user} />} />
          <Route path="/tasks" element={<TasksPage showToast={showToast} />} />
          <Route path="/history" element={<HistoryPage />} />
        </Routes>

        {/* Bottom Nav only on main tabs */}
        <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />

        {toast && <Toast message={toast.message} type={toast.type} />}
      </div>
    </BrowserRouter>
  )
}

// Telegram types
declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        ready: () => void
        expand: () => void
        initDataUnsafe?: {
          user?: {
            id: number
            username?: string
            first_name?: string
            photo_url?: string
          }
        }
      }
    }
  }
}
