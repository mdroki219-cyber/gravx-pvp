import { motion } from 'framer-motion'

export default function SplashScreen() {
  const particles = Array.from({ length: 14 })

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex flex-col items-center justify-center bg-[#050812]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,210,255,.16),transparent_42%),linear-gradient(180deg,#070b15,#03050b)]" />
      <div className="absolute inset-0 opacity-20 bg-[linear-gradient(rgba(0,220,255,.08)_1px,transparent_1px),linear-gradient(90deg,rgba(0,220,255,.08)_1px,transparent_1px)] bg-[size:30px_30px]" />

      {particles.map((_, i) => (
        <motion.i
          key={i}
          className="absolute w-1 h-1 rounded-full bg-cyan-300 shadow-[0_0_10px_rgba(0,220,255,.9)]"
          style={{ left: `${7 + (i * 37) % 88}%`, top: `${8 + (i * 53) % 82}%` }}
          animate={{ y: [0, -18, 0], opacity: [.15, .9, .15], scale: [1, 1.8, 1] }}
          transition={{ duration: 2.5 + (i % 4) * .6, repeat: Infinity, delay: i * -.27 }}
        />
      ))}

      <motion.div
        className="relative w-36 h-36 mb-7"
        initial={{ scale: .7, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: .8, ease: 'easeOut' }}
      >
        <div className="absolute inset-0 rounded-full border border-cyan-300/20" />
        <motion.div
          className="absolute inset-2 rounded-full border-2 border-transparent border-t-cyan-300 border-r-blue-500 gravx-spin-ring"
        />
        <motion.div
          className="absolute inset-7 rounded-2xl rotate-45 bg-gradient-to-br from-cyan-300 via-blue-500 to-purple-500 shadow-[0_0_45px_rgba(0,220,255,.45)]"
          animate={{ rotate: [45, 135, 225, 315, 405] }}
          transition={{ duration: 7, repeat: Infinity, ease: 'linear' }}
        />
        <div className="absolute inset-[38px] rounded-xl rotate-45 bg-[#07101e] border border-white/10" />
        <div className="absolute inset-0 flex items-center justify-center text-2xl font-black text-white">T</div>
      </motion.div>

      <motion.h1
        initial={{ y: 18, opacity: 0, filter: 'blur(8px)' }}
        animate={{ y: 0, opacity: 1, filter: 'blur(0px)' }}
        transition={{ duration: .7 }}
        className="text-4xl font-black tracking-[.18em] bg-gradient-to-r from-cyan-200 via-blue-400 to-purple-400 bg-clip-text text-transparent"
      >
        GRAVX
      </motion.h1>
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: 150 }}
        transition={{ duration: .8, delay: .2 }}
        className="mt-1 h-1 rounded-full bg-gradient-to-r from-cyan-300 via-blue-500 to-purple-500"
      />
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: .45 }}
        className="mt-4 text-sm text-gray-300 tracking-[.28em] uppercase"
      >
        PVP • Roulette • Win
      </motion.p>

      <div className="mt-10 w-52">
        <div className="h-1 rounded-full bg-white/10 overflow-hidden">
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
            className="h-full w-1/2 bg-gradient-to-r from-transparent via-cyan-300 to-transparent"
          />
        </div>
        <p className="mt-3 text-center text-[10px] text-gray-500 tracking-[.35em] uppercase">Loading...</p>
      </div>

      <p className="absolute bottom-8 text-[11px] text-gray-500">
        Powered by <span className="text-cyan-300 font-bold">TON</span>
      </p>
    </div>
  )
}
