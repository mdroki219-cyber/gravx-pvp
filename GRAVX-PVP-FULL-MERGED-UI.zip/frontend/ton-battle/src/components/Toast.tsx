import { motion } from 'framer-motion'
import clsx from 'clsx'

interface Props {
  message: string
  type: 'success' | 'error' | 'info'
}

export default function Toast({ message, type }: Props) {
  return (
    <motion.div
      initial={{ y: 80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 80, opacity: 0 }}
      className="fixed bottom-24 left-4 right-4 z-50 flex justify-center pointer-events-none"
    >
      <div
        className={clsx(
          'px-5 py-3 rounded-2xl text-sm font-medium shadow-lg max-w-sm text-center',
          type === 'success' && 'bg-emerald-500/90 text-white',
          type === 'error' && 'bg-red-500/90 text-white',
          type === 'info' && 'bg-ton-card border border-ton-border text-cyan-300'
        )}
      >
        {message}
      </div>
    </motion.div>
  )
}
