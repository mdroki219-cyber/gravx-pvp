import { useNavigate, useLocation } from 'react-router-dom'
import { Swords, CircleDot, Trophy, User } from 'lucide-react'
import clsx from 'clsx'
import type { TabId } from '../types'

interface Props {
  activeTab: TabId
  setActiveTab: (t: TabId) => void
}

const tabs = [
  { id: 'pvp' as TabId, label: 'PVP', icon: Swords, path: '/pvp' },
  { id: 'roulette' as TabId, label: 'Roulette', icon: CircleDot, path: '/roulette' },
  { id: 'leaderboard' as TabId, label: 'Leaderboard', icon: Trophy, path: '/leaderboard' },
  { id: 'profile' as TabId, label: 'Profile', icon: User, path: '/profile' },
]

export default function BottomNav({ setActiveTab }: Props) {
  const navigate = useNavigate()
  const location = useLocation()

  // Hide on sub-pages
  const hidePaths = ['/deposit', '/withdraw', '/referrals', '/tasks', '/history']
  if (hidePaths.some(p => location.pathname.startsWith(p))) return null

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0D1320]/95 backdrop-blur-md border-t border-ton-border safe-bottom">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-2">
        {tabs.map(tab => {
          const active = location.pathname === tab.path
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id)
                navigate(tab.path)
              }}
              className={clsx(
                'flex flex-col items-center justify-center gap-0.5 w-16 h-14 rounded-xl transition-all btn-press',
                active ? 'text-cyan-400' : 'text-gray-500 hover:text-gray-300'
              )}
            >
              <Icon size={22} strokeWidth={active ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{tab.label}</span>
              {active && (
                <div className="absolute bottom-1 w-1 h-1 rounded-full bg-cyan-400" />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}
