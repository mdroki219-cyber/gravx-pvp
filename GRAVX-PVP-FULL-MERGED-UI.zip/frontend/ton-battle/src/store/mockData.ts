import type { User, PvpPlayer, PvpGame, LeaderboardEntry, Task, Transaction, ReferralEntry } from '../types';

export const COLORS = [
  '#00F0FF', '#7B61FF', '#00E676', '#FF6B6B', '#FFD93D',
  '#FF8C42', '#4ECDC4', '#C44569', '#A55EEA', '#26de81'
];

export const BET_AMOUNTS = [0.10, 0.20, 0.50, 1.00, 3.00];

export const mockUser: User = {
  telegram_id: 123456789,
  username: 'ShadowHunter',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ShadowHunter',
  ton_balance: 24.80,
  referral_code: 'R8K4M2X9',
  referred_by: null,
  total_wins: 156.40,
  created_at: '2025-01-15T10:00:00Z',
};

export const mockPlayers: PvpPlayer[] = [
  { id: '1', username: 'CryptoKing', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CryptoKing', bet: 5.60, color: COLORS[0], chance: 0 },
  { id: '2', username: 'NovaStrike', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=NovaStrike', bet: 2.40, color: COLORS[1], chance: 0 },
  { id: '3', username: 'VenomLuck', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=VenomLuck', bet: 2.00, color: COLORS[2], chance: 0 },
];

export function calcChances(players: PvpPlayer[]): PvpPlayer[] {
  const total = players.reduce((s, p) => s + p.bet, 0) || 1;
  return players.map(p => ({
    ...p,
    chance: Math.round((p.bet / total) * 10000) / 100
  }));
}

export const initialPvpGame: PvpGame = {
  game_id: 'TB-92841',
  status: 'betting',
  players: calcChances(mockPlayers),
  total_pot: mockPlayers.reduce((s, p) => s + p.bet, 0),
  winner: null,
  countdown: 28,
  started_at: new Date().toISOString(),
  ended_at: null,
};

export const mockLeaderboard: LeaderboardEntry[] = [
  { rank: 1, username: 'DragonTON', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=DragonTON', total_win: 245.60 },
  { rank: 2, username: 'LuckyWhale', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=LuckyWhale', total_win: 198.40 },
  { rank: 3, username: 'SpinMaster', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=SpinMaster', total_win: 176.20 },
  { rank: 4, username: 'TONWarrior', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=TONWarrior', total_win: 154.80 },
  { rank: 5, username: 'CryptoFox', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CryptoFox', total_win: 143.20 },
  { rank: 6, username: 'NightRider', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=NightRider', total_win: 121.60 },
  { rank: 7, username: 'GoldSpin', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=GoldSpin', total_win: 108.40 },
  { rank: 8, username: 'PixelBet', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=PixelBet', total_win: 96.20 },
  { rank: 9, username: 'BlueRocket', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=BlueRocket', total_win: 87.60 },
  { rank: 10, username: 'ShadowX', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ShadowX', total_win: 75.40 },
];

export const mockTasks: Task[] = [
  { id: '1', name: 'Join Telegram Channel', reward: 0.10, status: 'available' },
  { id: '2', name: 'Invite a Friend', reward: 0.03, status: 'available' },
  { id: '3', name: 'Daily Login', reward: 0.05, status: 'available' },
  { id: '4', name: 'Place first PVP bet', reward: 0.15, status: 'completed' },
];

export const mockHistory: Transaction[] = [
  { id: 'tx1', type: 'pvp_win', amount: 4.80, status: 'completed', game_id: 'TB-92841', created_at: '2026-09-20T10:15:00Z' },
  { id: 'tx2', type: 'roulette', amount: -2.00, status: 'completed', game_id: 'R-10293', created_at: '2026-09-20T09:40:00Z' },
  { id: 'tx3', type: 'deposit', amount: 10.00, status: 'completed', created_at: '2026-09-19T18:22:00Z' },
  { id: 'tx4', type: 'withdraw', amount: -5.00, status: 'processing', wallet_address: 'EQD...f3A', created_at: '2026-09-19T14:10:00Z' },
  { id: 'tx5', type: 'referral', amount: 0.03, status: 'completed', created_at: '2026-09-18T11:05:00Z' },
];

export const mockReferrals: ReferralEntry[] = [
  { username: 'user123', reward: 0.03, date: '2026-09-18' },
  { username: 'user456', reward: 0.03, date: '2026-09-17' },
  { username: 'user789', reward: 0.03, date: '2026-09-15' },
];
