export interface User {
  telegram_id: number;
  username: string;
  avatar: string;
  ton_balance: number;
  referral_code: string;
  referred_by: string | null;
  total_wins: number;
  created_at: string;
}

export interface PvpPlayer {
  id: string;
  username: string;
  avatar: string;
  bet: number;
  color: string;
  chance: number;
}

export interface PvpGame {
  game_id: string;
  status: 'waiting' | 'betting' | 'spinning' | 'result' | 'ended';
  players: PvpPlayer[];
  total_pot: number;
  winner: PvpPlayer | null;
  countdown: number;
  started_at: string;
  ended_at: string | null;
}

export interface RouletteGame {
  game_id: string;
  spin_amount: number;
  result: number | null;
  payout: number;
  status: 'idle' | 'spinning' | 'result';
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdraw' | 'pvp_win' | 'pvp_bet' | 'roulette' | 'referral';
  amount: number;
  status: 'pending' | 'completed' | 'failed' | 'processing';
  wallet_address?: string;
  game_id?: string;
  created_at: string;
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  avatar: string;
  total_win: number;
}

export interface Task {
  id: string;
  name: string;
  reward: number;
  status: 'available' | 'in_progress' | 'completed' | 'claimed';
}

export interface ReferralEntry {
  username: string;
  reward: number;
  date: string;
}

export type TabId = 'pvp' | 'roulette' | 'leaderboard' | 'profile';
