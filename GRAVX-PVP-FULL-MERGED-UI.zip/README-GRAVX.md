# GRAVX PVP – Wallet behavior

- Deposit: user selects TON amount -> backend creates a unique GRAVX deposit comment -> Tonkeeper opens with exact amount -> backend watches TONAPI events and credits the user automatically after matching the unique comment and exact amount.
- Withdraw: user submits amount + TON address -> balance + 0.10 TON fee is reserved -> request appears in Admin -> admin sends TON manually and marks it sent, or rejects to refund the full reserved amount.
- Tasks: admin can add, edit, activate/deactivate, and delete tasks.

Production note: set a TONAPI key in `data/settings.json` or environment/secret management for reliable limits. Never put private wallet keys in the frontend.
