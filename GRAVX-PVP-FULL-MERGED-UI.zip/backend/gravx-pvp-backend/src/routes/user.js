import { Router } from 'express'
import { getUser, read } from '../utils/db.js'

const router = Router()

router.get('/:telegram_id', (req, res) => {
  const user = getUser(req.params.telegram_id)
  if (!user) return res.status(404).json({ error: 'Not found' })
  res.json({ user })
})

router.get('/:telegram_id/history', (req, res) => {
  const txs = read('transactions.json')
  const mine = txs.filter(t => String(t.user_id) === String(req.params.telegram_id))
  res.json({ history: mine.slice(0, 50) })
})

export default router
