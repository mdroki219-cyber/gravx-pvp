import { Router } from 'express'
import { getUser, saveUser, read, write } from '../utils/db.js'
import { genReferralCode, now } from '../utils/helpers.js'

const router = Router()

router.post('/login', (req, res) => {
  const { telegram_id, username, avatar, start_param } = req.body
  if (!telegram_id) return res.status(400).json({ error: 'telegram_id required' })

  let user = getUser(telegram_id)

  if (!user) {
    user = {
      telegram_id: String(telegram_id),
      username: username || `user_${telegram_id}`,
      avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${telegram_id}`,
      ton_balance: 0,
      referral_code: genReferralCode(),
      referred_by: null,
      total_wins: 0,
      total_bets: 0,
      created_at: now()
    }

    // Referral from start_param
    if (start_param) {
      const users = read('users.json')
      const referrer = users.find(u => u.referral_code === start_param)
      if (referrer && String(referrer.telegram_id) !== String(telegram_id)) {
        user.referred_by = referrer.telegram_id
        const settings = read('settings.json')
        const reward = settings.referral_reward || 0.03
        referrer.ton_balance = +(referrer.ton_balance + reward).toFixed(4)
        saveUser(referrer)

        const refs = read('referrals.json')
        refs.unshift({
          id: Date.now().toString(),
          referrer_id: referrer.telegram_id,
          referred_id: user.telegram_id,
          referred_username: user.username,
          reward,
          created_at: now()
        })
        write('referrals.json', refs)
      }
    }

    saveUser(user)
  } else {
    if (username) user.username = username
    if (avatar) user.avatar = avatar
    saveUser(user)
  }

  res.json({ user })
})

router.get('/me/:telegram_id', (req, res) => {
  const user = getUser(req.params.telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })
  res.json({ user })
})

export default router
