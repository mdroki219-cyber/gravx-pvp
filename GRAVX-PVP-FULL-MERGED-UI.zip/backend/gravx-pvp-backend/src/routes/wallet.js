import { Router } from 'express'
import { getUser, saveUser, addTransaction, read, write, readSettings } from '../utils/db.js'
import { genId, now } from '../utils/helpers.js'

const router = Router()
const NANO = 1_000_000_000

function makeDepositComment(id) { return `GRAVX:${id}` }

// Creates a pending deposit and returns a Tonkeeper payment link.
// The user never needs to submit a tx hash: the chain watcher matches the unique comment.
router.post('/deposit/request', (req, res) => {
  const { telegram_id, amount } = req.body
  const settings = readSettings()
  const minDeposit = Number(settings.min_deposit ?? 0.5)
  const value = Number(amount)
  if (!telegram_id || !Number.isFinite(value) || value < minDeposit) {
    return res.status(400).json({ error: `Minimum deposit is ${minDeposit} TON` })
  }
  if (!settings.platform_wallet) return res.status(500).json({ error: 'Platform wallet is not configured' })
  const user = getUser(telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })

  const amountFixed = +value.toFixed(9)
  const id = genId('dep_')
  const comment = makeDepositComment(id)
  const tx = {
    id,
    user_id: String(telegram_id),
    username: user.username,
    type: 'deposit',
    amount: amountFixed,
    fee: 0,
    total_debit: 0,
    status: 'pending',
    tx_hash: null,
    wallet_address: null,
    deposit_comment: comment,
    created_at: now()
  }
  addTransaction(tx)

  const nano = Math.round(amountFixed * NANO)
  const tonkeeperUrl = `https://app.tonkeeper.com/transfer/${encodeURIComponent(settings.platform_wallet)}?amount=${nano}&text=${encodeURIComponent(comment)}`
  res.json({ success: true, transaction: tx, tonkeeper_url: tonkeeperUrl, comment })
})

// Kept for backward compatibility, but normal deposits are now auto-confirmed by the watcher.
router.post('/deposit/confirm', (req, res) => {
  const { transaction_id } = req.body
  const txs = read('transactions.json')
  const tx = txs.find(t => t.id === transaction_id && t.type === 'deposit')
  if (!tx) return res.status(404).json({ error: 'Transaction not found' })
  if (tx.status === 'completed') return res.json({ success: true, message: 'Already completed' })
  return res.status(400).json({ error: 'Deposits are auto-confirmed from the TON blockchain; admin confirmation is disabled.' })
})

router.post('/withdraw/request', (req, res) => {
  const { telegram_id, amount, wallet_address } = req.body
  const settings = readSettings()
  const minW = Number(settings.min_withdraw ?? 1)
  const withdrawFee = Number(settings.withdraw_fee_ton ?? 0.10)
  const value = Number(amount)

  if (!telegram_id || !Number.isFinite(value) || value < minW) {
    return res.status(400).json({ error: `Minimum withdraw is ${minW} TON` })
  }
  if (!wallet_address || wallet_address.length < 10) {
    return res.status(400).json({ error: 'Valid TON wallet address required' })
  }
  const user = getUser(telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })
  const totalDebit = +(value + withdrawFee).toFixed(9)
  if (user.ton_balance < totalDebit) {
    return res.status(400).json({ error: `Insufficient balance. Withdrawal fee is ${withdrawFee.toFixed(2)} TON` })
  }

  user.ton_balance = +(user.ton_balance - totalDebit).toFixed(9)
  saveUser(user)
  const tx = {
    id: genId('wd_'), user_id: String(telegram_id), username: user.username,
    type: 'withdraw', amount: +value.toFixed(9), fee: withdrawFee,
    total_debit: totalDebit, status: 'pending', wallet_address,
    created_at: now()
  }
  addTransaction(tx)
  res.json({ success: true, transaction: tx, balance: user.ton_balance, fee: withdrawFee, total_debit: totalDebit })
})

export default router
