import { Router } from 'express'
import { getUser, read } from '../utils/db.js'

const router = Router()

router.get('/:telegram_id', (req, res) => {
  const user = getUser(req.params.telegram_id)
  if (!user) return res.status(404).json({ error: 'Not found' })

  const refs = read('referrals.json').filter(r => String(r.referrer_id) === String(req.params.telegram_id))
  const total = refs.reduce((s, r) => s + r.reward, 0)

  res.json({
    referral_code: user.referral_code,
    link: `https://t.me/YourBot?start=${user.referral_code}`,
    invited: refs.length,
    earnings: +total.toFixed(4),
    history: refs
  })
})

export default router
