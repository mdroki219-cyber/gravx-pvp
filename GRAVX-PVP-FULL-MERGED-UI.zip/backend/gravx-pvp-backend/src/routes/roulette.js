import { Router } from 'express'
import { randomInt } from 'node:crypto'
import { getUser, saveUser, addTransaction, readSettings } from '../utils/db.js'
import { genId, now } from '../utils/helpers.js'

const router = Router()

router.post('/spin', (req, res) => {
  const { telegram_id, amount, color } = req.body
  const selectedColor = String(color || '').toLowerCase()
  if (!['red', 'black', 'green'].includes(selectedColor)) {
    return res.status(400).json({ error: 'Color must be red, black or green' })
  }
  if (![0.10, 0.20, 0.50, 1.00, 3.00].includes(+amount)) {
    return res.status(400).json({ error: 'Amount must be 0.10, 0.20, 0.50, 1 or 3 TON' })
  }

  const user = getUser(telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })
  if (user.ton_balance < amount) return res.status(400).json({ error: 'Insufficient balance' })

  user.ton_balance = +(user.ton_balance - amount).toFixed(4)
  user.total_bets = +(user.total_bets + amount).toFixed(4)

  // European-style wheel: 37 slots total — 18 red, 18 black, exactly 1 green (0).
  // Use cryptographically secure randomness on the server so the client cannot choose the result.
  const number = randomInt(0, 37)
  const resultColor = number === 0 ? 'green' : (number % 2 === 0 ? 'red' : 'black')
  const settings = readSettings()
  const feePct = settings.roulette_fee_percent ?? 10
  let grossPayout = 0
  if (resultColor === selectedColor) grossPayout = selectedColor === 'green' ? amount * 100 : amount * 2
  const fee = +(grossPayout * (feePct / 100)).toFixed(4)
  const payout = +(grossPayout - fee).toFixed(4)

  if (payout > 0) {
    user.ton_balance = +(user.ton_balance + payout).toFixed(4)
    user.total_wins = +(user.total_wins + payout).toFixed(4)
  }
  saveUser(user)

  const game_id = genId('R-')
  addTransaction({
    id: genId('rou_'),
    user_id: String(telegram_id),
    username: user.username,
    type: 'roulette',
    amount: payout > 0 ? payout - amount : -amount,
    gross_payout: grossPayout,
    fee: fee,
    status: 'completed',
    game_id,
    result: number,
    created_at: now()
  })

  res.json({
    success: true,
    game_id,
    number,
    result_color: resultColor,
    selected_color: selectedColor,
    payout,
    gross_payout: grossPayout,
    fee,
    fee_percent: feePct,
    balance: user.ton_balance,
    won: payout > 0
  })
})

export default router
