import { Router } from 'express'
import { getUser, saveUser, read, write, addTransaction, readSettings } from '../utils/db.js'
import { genId, now } from '../utils/helpers.js'

const router = Router()
const COLORS = ['#00F0FF','#7B61FF','#00E676','#FF6B6B','#FFD93D','#FF8C42','#4ECDC4','#C44569','#A55EEA','#26de81']
const BET_AMOUNTS = [0.10,0.20,0.50,1.00,3.00]

function getOrCreateActiveGame() {
  let games = read('pvp_games.json')
  let active = games.find(g => g.status === 'betting' || g.status === 'waiting')
  if (!active) {
    active = {
      game_id: genId('TB-'),
      status: 'betting',
      players: [],
      total_pot: 0,
      winner: null,
      countdown: 30,
      started_at: now(),
      ended_at: null
    }
    games.unshift(active)
    write('pvp_games.json', games)
  }
  return active
}

function calcChances(players) {
  const total = players.reduce((s, p) => s + p.bet, 0) || 1
  return players.map(p => ({
    ...p,
    chance: Math.round((p.bet / total) * 10000) / 100
  }))
}

// Get current game
router.get('/current', (req, res) => {
  const game = getOrCreateActiveGame()
  res.json({ game })
})

// Place bet
router.post('/bet', (req, res) => {
  const { telegram_id, amount } = req.body
  if (!BET_AMOUNTS.includes(+amount)) {
    return res.status(400).json({ error: 'Invalid bet amount' })
  }

  const user = getUser(telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })
  if (user.ton_balance < amount) return res.status(400).json({ error: 'Insufficient balance' })

  let games = read('pvp_games.json')
  let game = games.find(g => g.status === 'betting')
  if (!game) {
    game = getOrCreateActiveGame()
    games = read('pvp_games.json')
  }

  // Already bet this round?
  if (game.players.some(p => String(p.telegram_id) === String(telegram_id))) {
    return res.status(400).json({ error: 'Already placed bet this round' })
  }

  // Deduct balance
  user.ton_balance = +(user.ton_balance - amount).toFixed(4)
  user.total_bets = +(user.total_bets + amount).toFixed(4)
  saveUser(user)

  const player = {
    telegram_id: String(telegram_id),
    username: user.username,
    avatar: user.avatar,
    bet: +amount,
    color: COLORS[game.players.length % COLORS.length],
    chance: 0
  }
  game.players.push(player)
  game.players = calcChances(game.players)
  game.total_pot = +game.players.reduce((s, p) => s + p.bet, 0).toFixed(4)

  const idx = games.findIndex(g => g.game_id === game.game_id)
  games[idx] = game
  write('pvp_games.json', games)

  addTransaction({
    id: genId('bet_'),
    user_id: String(telegram_id),
    username: user.username,
    type: 'pvp_bet',
    amount: -amount,
    status: 'completed',
    game_id: game.game_id,
    created_at: now()
  })

  res.json({ success: true, game, balance: user.ton_balance })
})

// Spin / settle (can be called by timer or admin)
router.post('/settle', (req, res) => {
  let games = read('pvp_games.json')
  let game = games.find(g => g.status === 'betting' || g.status === 'spinning')
  if (!game || game.players.length === 0) {
    return res.status(400).json({ error: 'No active game to settle' })
  }

  game.status = 'spinning'

  // Weighted random winner
  const total = game.total_pot
  let r = Math.random() * total
  let winner = game.players[0]
  for (const p of game.players) {
    r -= p.bet
    if (r <= 0) { winner = p; break }
  }

  const settings = readSettings()
  const feePct = settings.platform_fee_percent ?? 10
  const payout = +(game.total_pot * (1 - feePct / 100)).toFixed(4)

  // Credit winner
  const winUser = getUser(winner.telegram_id)
  if (winUser) {
    winUser.ton_balance = +(winUser.ton_balance + payout).toFixed(4)
    winUser.total_wins = +(winUser.total_wins + payout).toFixed(4)
    saveUser(winUser)

    addTransaction({
      id: genId('win_'),
      user_id: String(winner.telegram_id),
      username: winner.username,
      type: 'pvp_win',
      amount: payout,
      status: 'completed',
      game_id: game.game_id,
      created_at: now()
    })
  }

  game.winner = winner
  game.status = 'result'
  game.ended_at = now()
  game.payout = payout

  const idx = games.findIndex(g => g.game_id === game.game_id)
  games[idx] = game
  write('pvp_games.json', games)

  // Create next round
  setTimeout(() => {
    const g2 = read('pvp_games.json')
    g2.unshift({
      game_id: genId('TB-'),
      status: 'betting',
      players: [],
      total_pot: 0,
      winner: null,
      countdown: 30,
      started_at: now(),
      ended_at: null
    })
    write('pvp_games.json', g2)
  }, 6000)

  res.json({ success: true, game, winner, payout })
})

router.get('/history', (req, res) => {
  const games = read('pvp_games.json').filter(g => g.status === 'result').slice(0, 20)
  res.json({ games })
})

export default router
