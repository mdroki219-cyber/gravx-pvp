import { Router } from 'express'
import { read, write, getUser, saveUser, addTransaction } from '../utils/db.js'
import { genId, now } from '../utils/helpers.js'

const router = Router()

router.get('/', (req, res) => {
  const tasks = read('tasks.json').filter(t => t.status === 'active')
  res.json({ tasks })
})

// Claim task reward (simple - in real app verify join etc.)
router.post('/claim', (req, res) => {
  const { telegram_id, task_id } = req.body
  const tasks = read('tasks.json')
  const task = tasks.find(t => t.id === task_id)
  if (!task) return res.status(404).json({ error: 'Task not found' })

  const user = getUser(telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })

  // Prevent double claim - store claimed tasks on user
  if (!user.claimed_tasks) user.claimed_tasks = []
  if (user.claimed_tasks.includes(task_id)) {
    return res.status(400).json({ error: 'Already claimed' })
  }

  user.claimed_tasks.push(task_id)
  user.ton_balance = +(user.ton_balance + task.reward).toFixed(4)
  saveUser(user)

  addTransaction({
    id: genId('task_'),
    user_id: String(telegram_id),
    username: user.username,
    type: 'task',
    amount: task.reward,
    status: 'completed',
    created_at: now()
  })

  res.json({ success: true, reward: task.reward, balance: user.ton_balance })
})

export default router
