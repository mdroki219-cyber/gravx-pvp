import { Router } from 'express'
import { read, write, getUser, saveUser, readSettings, addTransaction } from '../utils/db.js'
import { genId, now } from '../utils/helpers.js'

const router = Router()

// Simple admin auth middleware
function adminAuth(req, res, next) {
  const key = req.headers['x-admin-key'] || req.query.key
  const settings = readSettings()
  if (key !== settings.admin_key) {
    return res.status(401).json({ error: 'Unauthorized' })
  }
  next()
}

router.use(adminAuth)

// Dashboard stats
router.get('/dashboard', (req, res) => {
  const users = read('users.json')
  const txs = read('transactions.json')
  const games = read('pvp_games.json')

  const pendingWithdrawals = txs.filter(t => t.type === 'withdraw' && t.status === 'pending')
  const totalVolume = txs
    .filter(t => t.status === 'completed' && (t.type === 'deposit' || t.type === 'pvp_bet' || t.type === 'roulette'))
    .reduce((s, t) => s + Math.abs(t.amount), 0)

  res.json({
    total_users: users.length,
    total_volume: +totalVolume.toFixed(2),
    active_matches: games.filter(g => g.status === 'betting' || g.status === 'spinning').length,
    pending_withdrawals: pendingWithdrawals.length,
    pending_amount: +pendingWithdrawals.reduce((s, t) => s + t.amount, 0).toFixed(2),
    recent_transactions: txs.slice(0, 15)
  })
})

// All users
router.get('/users', (req, res) => {
  const users = read('users.json')
  res.json({ users, total: users.length })
})

// Adjust balance (optional emergency)
router.post('/users/adjust-balance', (req, res) => {
  const { telegram_id, amount, reason } = req.body
  const user = getUser(telegram_id)
  if (!user) return res.status(404).json({ error: 'User not found' })

  user.ton_balance = +(user.ton_balance + amount).toFixed(4)
  saveUser(user)

  addTransaction({
    id: genId('adj_'),
    user_id: String(telegram_id),
    username: user.username,
    type: amount > 0 ? 'admin_credit' : 'admin_debit',
    amount: +amount,
    status: 'completed',
    reason: reason || 'Admin adjust',
    created_at: now()
  })

  res.json({ success: true, user })
})

// Pending withdrawals list
router.get('/withdrawals/pending', (req, res) => {
  const txs = read('transactions.json')
  const pending = txs.filter(t => t.type === 'withdraw' && t.status === 'pending')
  res.json({ withdrawals: pending })
})

// Complete / Approve withdraw
router.post('/withdrawals/complete', (req, res) => {
  const { transaction_id } = req.body
  const txs = read('transactions.json')
  const tx = txs.find(t => t.id === transaction_id && t.type === 'withdraw')
  if (!tx) return res.status(404).json({ error: 'Not found' })
  if (tx.status !== 'pending') return res.status(400).json({ error: 'Not pending' })

  // In real system: send TON from platform wallet to tx.wallet_address
  // Here we mark completed (you send manually or via TON API later)
  tx.status = 'completed'
  tx.completed_at = now()
  write('transactions.json', txs)

  res.json({
    success: true,
    message: 'Withdrawal marked complete. Send TON to: ' + tx.wallet_address,
    transaction: tx
  })
})

// Reject withdraw (refund balance)
router.post('/withdrawals/reject', (req, res) => {
  const { transaction_id, reason } = req.body
  const txs = read('transactions.json')
  const tx = txs.find(t => t.id === transaction_id && t.type === 'withdraw')
  if (!tx) return res.status(404).json({ error: 'Not found' })
  if (tx.status !== 'pending') return res.status(400).json({ error: 'Not pending' })

  const user = getUser(tx.user_id)
  if (user) {
    user.ton_balance = +(user.ton_balance + Number(tx.total_debit || tx.amount)).toFixed(9)
    saveUser(user)
  }

  tx.status = 'rejected'
  tx.reason = reason || 'Rejected by admin'
  tx.completed_at = now()
  write('transactions.json', txs)

  res.json({ success: true, transaction: tx })
})

// Manual deposit confirmation is intentionally disabled. Deposits are confirmed by the blockchain watcher.
router.post('/deposits/confirm', (req, res) => {
  res.status(400).json({ error: 'Deposits are automatic. Admin confirmation is disabled.' })
})

// Tasks management
router.get('/tasks', (req, res) => {
  res.json({ tasks: read('tasks.json') })
})

router.post('/tasks/add', (req, res) => {
  const { name, reward, link } = req.body
  if (!name || reward == null) return res.status(400).json({ error: 'name and reward required' })

  const tasks = read('tasks.json')
  const task = {
    id: genId('task_'),
    name,
    reward: +reward,
    link: link || null,
    status: 'active',
    created_at: now()
  }
  tasks.push(task)
  write('tasks.json', tasks)
  res.json({ success: true, task })
})

router.post('/tasks/update', (req, res) => {
  const { id, name, reward, link, status } = req.body
  const tasks = read('tasks.json')
  const idx = tasks.findIndex(t => t.id === id)
  if (idx < 0) return res.status(404).json({ error: 'Not found' })

  if (name) tasks[idx].name = name
  if (reward != null) tasks[idx].reward = +reward
  if (link !== undefined) tasks[idx].link = link
  if (status) tasks[idx].status = status
  write('tasks.json', tasks)
  res.json({ success: true, task: tasks[idx] })
})

router.post('/tasks/delete', (req, res) => {
  const { id } = req.body
  const tasks = read('tasks.json')
  const next = tasks.filter(t => t.id !== id)
  if (next.length === tasks.length) return res.status(404).json({ error: 'Not found' })
  write('tasks.json', next)
  res.json({ success: true })
})

// All transactions
router.get('/transactions', (req, res) => {
  const txs = read('transactions.json')
  res.json({ transactions: txs.slice(0, 100) })
})

// Matches
router.get('/matches', (req, res) => {
  const games = read('pvp_games.json')
  res.json({ matches: games.slice(0, 30) })
})

// Settings
router.get('/settings', (req, res) => {
  res.json({ settings: readSettings() })
})

router.post('/settings', (req, res) => {
  const current = readSettings()
  const updated = { ...current, ...req.body }
  write('settings.json', updated)
  res.json({ success: true, settings: updated })
})

export default router
