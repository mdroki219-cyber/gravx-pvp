import { read, write, getUser, saveUser } from './db.js'

const NANO = 1_000_000_000

function headers(settings) {
  const h = { 'Accept': 'application/json' }
  if (settings.tonapi_api_key) h.Authorization = `Bearer ${settings.tonapi_api_key}`
  return h
}

function walk(obj, out = []) {
  if (!obj || typeof obj !== 'object') return out
  if (Array.isArray(obj)) { for (const x of obj) walk(x, out); return out }
  out.push(obj)
  for (const v of Object.values(obj)) if (v && typeof v === 'object') walk(v, out)
  return out
}

function extractTransfer(event, platformWallet) {
  const nodes = walk(event)
  for (const n of nodes) {
    const t = n.TonTransfer || n.ton_transfer || n.tonTransfer
    if (!t || typeof t !== 'object') continue
    const recipient = t.recipient?.address || t.recipient || t.destination?.address || t.destination
    const sender = t.sender?.address || t.sender || t.source?.address || t.source
    const amount = Number(t.amount)
    const comment = t.comment || t.payload?.comment || t.message?.comment || ''
    if (recipient && String(recipient) === String(platformWallet) && Number.isFinite(amount)) {
      return { sender, recipient, amount, comment: String(comment || ''), tx_hash: event.event_id || event.id || event.tx_hash || null }
    }
  }
  // Some TonAPI responses expose a top-level event_id and actions with comment/value fields.
  for (const n of nodes) {
    const recipient = n.recipient?.address || n.recipient
    const amount = Number(n.amount)
    const comment = n.comment || n.payload?.comment || ''
    if (recipient && String(recipient) === String(platformWallet) && Number.isFinite(amount) && comment) {
      return { sender: n.sender?.address || n.sender || null, recipient, amount, comment: String(comment), tx_hash: event.event_id || event.id || event.tx_hash || null }
    }
  }
  return null
}

async function fetchEvents(settings) {
  const base = String(settings.tonapi_url || 'https://tonapi.io').replace(/\/$/, '')
  const url = `${base}/v2/accounts/${encodeURIComponent(settings.platform_wallet)}/events?limit=100`
  const r = await fetch(url, { headers: headers(settings) })
  if (!r.ok) throw new Error(`TONAPI ${r.status}`)
  return r.json()
}

async function scan() {
  const settings = read('settings.json')
  if (!settings.platform_wallet) return
  const txs = read('transactions.json')
  const pending = txs.filter(t => t.type === 'deposit' && t.status === 'pending' && t.deposit_comment)
  if (!pending.length) return

  const data = await fetchEvents(settings)
  const events = data.events || []
  const byComment = new Map(pending.map(t => [String(t.deposit_comment), t]))

  for (const event of events) {
    const transfer = extractTransfer(event, settings.platform_wallet)
    if (!transfer || !byComment.has(transfer.comment)) continue
    const tx = byComment.get(transfer.comment)
    if (!tx || tx.status !== 'pending') continue
    const received = transfer.amount / NANO
    // Exact requested amount, with a tiny tolerance for representation differences.
    if (Math.abs(received - Number(tx.amount)) > 0.000001) continue

    const alreadyUsed = txs.some(t => t.type === 'deposit' && t.status === 'completed' && t.tx_hash && t.tx_hash === transfer.tx_hash)
    if (alreadyUsed) continue

    const user = getUser(tx.user_id)
    if (!user) continue
    user.ton_balance = +(Number(user.ton_balance || 0) + received).toFixed(9)
    saveUser(user)
    tx.status = 'completed'
    tx.tx_hash = transfer.tx_hash
    tx.wallet_address = transfer.sender || null
    tx.confirmed_at = new Date().toISOString()
  }
  write('transactions.json', txs)
}

export function startDepositWatcher() {
  const settings = read('settings.json')
  const interval = Math.max(10, Number(settings.deposit_poll_seconds || 15)) * 1000
  const run = () => scan().catch(err => console.error('[deposit-watcher]', err.message))
  run()
  return setInterval(run, interval)
}
