import fs from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const dataDir = join(__dirname, '../../data')

export function read(file) {
  const p = join(dataDir, file)
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'))
  } catch {
    return []
  }
}

export function write(file, data) {
  const p = join(dataDir, file)
  fs.writeFileSync(p, JSON.stringify(data, null, 2))
}

export function readSettings() {
  return read('settings.json')
}

export function getUser(telegramId) {
  const users = read('users.json')
  return users.find(u => String(u.telegram_id) === String(telegramId))
}

export function saveUser(user) {
  const users = read('users.json')
  const idx = users.findIndex(u => String(u.telegram_id) === String(user.telegram_id))
  if (idx >= 0) users[idx] = user
  else users.push(user)
  write('users.json', users)
  return user
}

export function addTransaction(tx) {
  const list = read('transactions.json')
  list.unshift(tx)
  write('transactions.json', list)
  return tx
}
