import { randomBytes } from 'crypto'

export function genId(prefix = '') {
  return prefix + randomBytes(4).toString('hex')
}

export function genReferralCode() {
  return randomBytes(4).toString('hex').toUpperCase()
}

export function now() {
  return new Date().toISOString()
}
