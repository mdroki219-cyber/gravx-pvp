import express from 'express'
import cors from 'cors'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import fs from 'fs'

import authRoutes from './routes/auth.js'
import userRoutes from './routes/user.js'
import pvpRoutes from './routes/pvp.js'
import rouletteRoutes from './routes/roulette.js'
import walletRoutes from './routes/wallet.js'
import adminRoutes from './routes/admin.js'
import taskRoutes from './routes/tasks.js'
import referralRoutes from './routes/referral.js'
import { startDepositWatcher } from './utils/depositWatcher.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const app = express()
const PORT = process.env.PORT || 3001

// Ensure data folder + files exist
const dataDir = join(__dirname, '../data')
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true })

const files = ['users.json', 'pvp_games.json', 'transactions.json', 'tasks.json', 'referrals.json', 'settings.json']
files.forEach(f => {
  const p = join(dataDir, f)
  if (!fs.existsSync(p)) {
    if (f === 'settings.json') {
      fs.writeFileSync(p, JSON.stringify({
        platform_wallet: 'UQDc6pNfXRtGjWs5Yy5FX6kYN7pzMtgfRv-ZjonmvfTKtT5x',
        platform_fee_percent: 10,
        min_deposit: 0.5,
        min_withdraw: 1,
        withdraw_fee_ton: 0.10,
        referral_reward: 0.03,
        admin_key: 'gravx_admin_2026'
      }, null, 2))
    } else if (f === 'tasks.json') {
      fs.writeFileSync(p, JSON.stringify([
        { id: '1', name: 'Join Telegram Channel', reward: 0.10, link: 'https://t.me/gravxpvp', status: 'active' },
        { id: '2', name: 'Invite a Friend', reward: 0.03, link: null, status: 'active' },
        { id: '3', name: 'Daily Login', reward: 0.05, link: null, status: 'active' }
      ], null, 2))
    } else {
      fs.writeFileSync(p, '[]')
    }
  }
})

app.use(cors({ origin: true, credentials: true }))
app.use(express.json())

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/user', userRoutes)
app.use('/api/pvp', pvpRoutes)
app.use('/api/roulette', rouletteRoutes)
app.use('/api/wallet', walletRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/tasks', taskRoutes)
app.use('/api/referral', referralRoutes)

app.use('/admin', express.static(join(__dirname, '../admin')))

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'GRAVX PVP' }))

app.listen(PORT, () => {
  console.log(`GRAVX PVP Backend running on http://localhost:${PORT}`)
  startDepositWatcher()
})
