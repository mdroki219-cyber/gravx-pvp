import { useState } from 'react'
import { motion } from 'framer-motion'
import { Minus, Plus } from 'lucide-react'
import type { User } from '../types'
import clsx from 'clsx'

interface Props {
  user: User
  updateBalance: (delta: number) => void
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void
}

const SPIN_AMOUNTS = [0.10, 0.20, 0.50, 1.00, 3.00]

export default function RoulettePage({ user, updateBalance, showToast }: Props) {
  const [amountIndex, setAmountIndex] = useState(0)
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<number | null>(null)
  const [history, setHistory] = useState<number[]>([7, 3, 12, 0, 18, 5, 22])
  const [rotation, setRotation] = useState(0)
  const [selectedColor, setSelectedColor] = useState<'red' | 'black' | 'green'>('red')

  const amount = SPIN_AMOUNTS[amountIndex]

  const spin = () => {
    if (spinning) return
    if (user.ton_balance < amount) {
      showToast('Insufficient TON balance', 'error')
      return
    }

    updateBalance(-amount)
    setSpinning(true)
    setResult(null)

    // European-style wheel: 18 red, 18 black, and exactly 1 green (0).
    const number = Math.floor(Math.random() * 37)
    const extra = 5 + Math.random() * 3
    const finalRot = extra * 360 + (number * (360 / 37))

    setRotation(prev => prev + finalRot)

    setTimeout(() => {
      setSpinning(false)
      setResult(number)
      setHistory(h => [number, ...h].slice(0, 10))

      const resultColor: 'red' | 'black' | 'green' = number === 0 ? 'green' : (number % 2 === 0 ? 'red' : 'black')

      // Color payout: Red/Black = 2x, single Green = 100x.
      let payout = 0
      if (resultColor === selectedColor) {
        payout = resultColor === 'green' ? amount * 100 : amount * 2
        // 10% roulette platform fee is deducted from winnings.
        payout = +(payout * 0.90).toFixed(4)
      }

      if (payout > 0) {
        updateBalance(payout)
        showToast(`You won ${payout.toFixed(2)} TON after 10% fee! 🎉`, 'success')
      } else {
        showToast(`Result: ${number} (${resultColor}) — Better luck next time`, 'info')
      }
    }, 4500)
  }

  return (
    <div className="safe-top safe-bottom min-h-screen pb-20 px-4 pt-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold">Roulette</h1>
        <div className="bg-ton-card border border-ton-border rounded-full px-4 py-1.5 flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500" />
          <span className="font-bold text-cyan-300 text-sm">{user.ton_balance.toFixed(2)} TON</span>
        </div>
      </div>

      {/* Wheel visual */}
      <div className="relative mx-auto w-56 h-56 sm:w-64 sm:h-64 my-6">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10">
          <div className="w-0 h-0 border-l-[8px] border-r-[8px] border-t-[14px] border-l-transparent border-r-transparent border-t-white" />
        </div>
        <div
          className="w-full h-full rounded-full border-4 border-ton-border"
          style={{
            background: 'conic-gradient(#e74c3c 0deg 10deg, #2c3e50 10deg 20deg, #e74c3c 20deg 30deg, #2c3e50 30deg 40deg, #e74c3c 40deg 50deg, #2c3e50 50deg 60deg, #27ae60 60deg 70deg, #e74c3c 70deg 80deg, #2c3e50 80deg 90deg, #e74c3c 90deg 100deg, #2c3e50 100deg 110deg, #e74c3c 110deg 120deg, #2c3e50 120deg 130deg, #e74c3c 130deg 140deg, #2c3e50 140deg 150deg, #e74c3c 150deg 160deg, #2c3e50 160deg 170deg, #e74c3c 170deg 180deg, #2c3e50 180deg 190deg, #e74c3c 190deg 200deg, #2c3e50 200deg 210deg, #e74c3c 210deg 220deg, #2c3e50 220deg 230deg, #e74c3c 230deg 240deg, #2c3e50 240deg 250deg, #e74c3c 250deg 260deg, #2c3e50 260deg 270deg, #e74c3c 270deg 280deg, #2c3e50 280deg 290deg, #e74c3c 290deg 300deg, #2c3e50 300deg 310deg, #e74c3c 310deg 320deg, #2c3e50 320deg 330deg, #e74c3c 330deg 340deg, #2c3e50 340deg 350deg, #e74c3c 350deg 360deg)',
            transform: `rotate(${rotation}deg)`,
            transition: spinning ? 'transform 4.5s cubic-bezier(0.15, 0.85, 0.25, 1)' : 'none',
          }}
        >
          <div className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-ton-dark border-2 border-gray-600 flex items-center justify-center">
            <span className="text-xs font-bold">{result !== null ? result : '•'}</span>
          </div>
        </div>
      </div>

      {/* Amount control */}
      <div className="bg-ton-card border border-ton-border rounded-2xl p-4">
        <p className="text-xs text-gray-400 text-center mb-3">Spin Amount</p>
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => setAmountIndex(i => Math.max(0, i - 1))}
            disabled={amountIndex === 0 || spinning}
            className="w-12 h-12 rounded-full bg-ton-dark border border-ton-border flex items-center justify-center disabled:opacity-40 btn-press"
          >
            <Minus size={20} />
          </button>
          <div className="min-w-[80px] text-center">
            <p className="text-2xl font-extrabold text-cyan-300">{amount}</p>
            <p className="text-xs text-gray-400">TON</p>
          </div>
          <button
            onClick={() => setAmountIndex(i => Math.min(SPIN_AMOUNTS.length - 1, i + 1))}
            disabled={amountIndex === SPIN_AMOUNTS.length - 1 || spinning}
            className="w-12 h-12 rounded-full bg-ton-dark border border-ton-border flex items-center justify-center disabled:opacity-40 btn-press"
          >
            <Plus size={20} />
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-4">
          {([
            { id: 'red' as const, label: 'RED', cls: 'bg-red-600 border-red-500' },
            { id: 'black' as const, label: 'BLACK', cls: 'bg-gray-950 border-gray-600' },
            { id: 'green' as const, label: 'GREEN ×100', cls: 'bg-emerald-600 border-emerald-400' },
          ]).map(option => (
            <button
              key={option.id}
              type="button"
              onClick={() => setSelectedColor(option.id)}
              disabled={spinning}
              className={clsx(
                'py-3 rounded-xl border-2 text-xs font-extrabold btn-press transition',
                option.cls,
                selectedColor === option.id ? 'ring-2 ring-cyan-300 scale-[1.02]' : 'opacity-70'
              )}
            >
              {option.label}
            </button>
          ))}
        </div>
        <p className="text-center text-[11px] text-gray-400 mt-2">Red/Black pay 2× • Green has 1 slot and pays 100×</p>

        <button
          onClick={spin}
          disabled={spinning}
          className={clsx(
            'mt-4 w-full py-3.5 rounded-xl font-bold text-base btn-press',
            spinning
              ? 'bg-gray-700 text-gray-400'
              : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white glow-cyan'
          )}
        >
          {spinning ? 'SPINNING...' : 'SPIN'}
        </button>
      </div>

      {/* Recent results */}
      <div className="mt-5">
        <p className="text-xs text-gray-400 mb-2 uppercase tracking-wider">Recent Results</p>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {history.map((n, i) => (
            <div
              key={i}
              className={clsx(
                'w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold shrink-0',
                n === 0 ? 'bg-emerald-600' : n % 2 === 0 ? 'bg-red-600' : 'bg-gray-800 border border-gray-600'
              )}
            >
              {n}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
