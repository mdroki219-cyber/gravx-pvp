import { motion } from 'framer-motion'

export default function SplashScreen() {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-b from-[#0A0E17] via-[#0D1526] to-[#0A0E17]">
      
      {/* App Name - No Logo */}
      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="text-4xl font-extrabold tracking-wider bg-gradient-to-r from-cyan-300 via-blue-400 to-purple-400 bg-clip-text text-transparent"
      >
        GRAVX PVP
      </motion.h1>

      {/* Tagline */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.35 }}
        className="mt-4 text-base text-gray-300 tracking-wide"
      >
        Compete • Win • Earn TON
      </motion.p>

      {/* Powered by */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.55 }}
        className="mt-2 text-sm text-gray-500"
      >
        Powered by TON
      </motion.p>

      {/* Loading bar */}
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: '55%' }}
        transition={{ delay: 0.8, duration: 1.3, ease: 'easeInOut' }}
        className="mt-12 h-1 rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 max-w-[180px]"
      />
      
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.0 }}
        className="mt-4 text-xs text-gray-500 tracking-widest uppercase"
      >
        Loading...
      </motion.p>
    </div>
  )
}
